<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title }} - EasyList</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/img/logo/icon.png') }}">

    <style>
        body {
            font-family: "Noto Kufi Arabic", sans-serif;
            font-optical-sizing: auto;
            font-style: normal;
        }

        .login {
            height: 100vh;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login_box {
            width: 1050px;
            height: 600px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 1px 4px 22px -8px #0004;
            display: flex;
            overflow: hidden;
        }

        .login_box .left {
            width: 41%;
            background: url('{{ asset('assets/img/logo/office-material-table.jpg') }}') no-repeat center center;
            background-size: cover;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            text-align: center;
        }

        .left .left-text {
            text-align: center;
            color: #fff;
        }

        .left .left-text h5 {
            font-size: 19px;
            font-weight: 400;
        }

        .login_box .right {
            width: 59%;
            padding: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .right .contact {
            width: 80%;
            text-align: center;
        }

        .right h3 {
            margin-bottom: 40px;
        }

        .right input {
            border: none;
            margin: 15px 0;
            border-bottom: 1px solid #4f30677d;
            padding: 7px 9px;
            width: 100%;
            background: transparent;
            font-weight: 600;
            font-size: 14px;
            text-align: right;
            direction: rtl;
            transition: border-color 0.3s, box-shadow 0.3s; /* Smooth transition for focus effect */
        }

        /* Placeholder style */
        .right input::placeholder {
            font-weight: 400;
        }

        /* Focus style */
        .right input:focus {
            outline: none; /* Remove default outline */
            border-bottom: 1px solid #2da9f7; /* Change border color on focus */
        }

        .submit {
            border: none;
            padding: 11px 40px;
            border-radius: 8px;
            margin-top: 20px;
            background: #2da9f7;
            color: #fff;
            cursor: pointer;
            transition: background 0.3s; /* Smooth transition for hover */
        }

        /* Button hover effect */
        .submit:hover {
            background: #1a8cd8; /* Darker shade on hover */
        }

        /* Logo styling */
        .right .logo-icon {
            position: absolute;
            top: 50px;
            right: 50px;
            width: 50px;
        }
    </style>
</head>
<body>
    <section class="login">
        <div class="login_box">
            <div class="left">
                <div class="left-text">
                    <!--<h5>وكالة إبداعية تعتمد على تجربة المستخدم</h5>-->
                </div>
            </div>
            <div class="right">
                <img src="{{ asset('assets/img/logo/icon.png') }}" alt="Logo" class="logo-icon">
                <div class="contact">
                    <form action="{{ route('authenticate') }}" method="POST">
                        @csrf
                        <h3>تسجيل الدخول</h3>
                        <input type="email" placeholder="البريد الإلكتروني" name="email" required>
                        <input type="password" placeholder="كلمة السر" name="password" required>
                        <button class="submit btn-sm" type="submit">دخول</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha384-ZvpUoO/+PpR2jLJ9e36s1L9UGbJ9cvi4IH6lF10YV9hjq7j7yq7H+J/PVZxB07Tz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js" integrity="sha384-jR2dpD/VcOSKyT6dDcxzCqauZnTL6bFzNxkYc1kTwj/8B3s8qGb2ne3MGxYxLlZ7" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgPSUGm7pV2lZtLeY4wrAqB/2l0O6q5aA3L/RjcmNEZgJ/nICp2" crossorigin="anonymous"></script>
</body>
</html>
