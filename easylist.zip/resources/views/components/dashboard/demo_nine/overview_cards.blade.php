<div class="col-xxl-4 col-xl-6 col-lg-12 mb-25">
              <div class="row">
                <div class="col-md-6">





                  <div class="overview-content overview-content3 pt-20 pb-20 text-center radius-xl">
                    <div class="d-inline-flex flex-column align-items-center justify-content-center">
                      <div class="revenue-chart-box__Icon order-bg-opacity-primary me-0">
                        <i class="uil uil-briefcase-alt"></i>
                      </div>
                      <div class="d-flex align-items-start flex-wrap">
                        <div class="mt-3">
                          <p class="mb-1 mb-0 color-gray">Total Products </p>
                          <h2>21K</h2>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
                <div class="col-md-6">





                  <div class="overview-content overview-content3 pt-20 pb-20 text-center radius-xl">
                    <div class="d-inline-flex flex-column align-items-center justify-content-center">
                      <div class="revenue-chart-box__Icon order-bg-opacity-secondary me-0">
                        <i class="uil uil-award"></i>
                      </div>
                      <div class="d-flex align-items-start flex-wrap">
                        <div class="mt-3">
                          <p class="mb-1 mb-0 color-gray">Total Awards</p>
                          <h2>15K</h2>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>
                <div class="col-12 mt-25">
                  <div class="card banner-feature banner-feature--7 border-0 mb-0">
                    <div class="d-flex justify-content-center">
                      <div class="card-body py-30 px-30">
                        <div class="banner-feature__shape me-20">
                          <img src="{{ asset('assets/img/svg/message2.svg') }}" alt="img" class="svg">
                        </div>
                        <div class="div">
                          <h2 class="banner-feature__heading">Subscribe to our newsletter</h2>
                          <p class="banner-feature__para ">Lorem ipsum dolor sit amet, consetetur</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>