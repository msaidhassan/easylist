{{-- <div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <div class="footer-copyright">
                <p>© @php date_default_timezone_set('Asia/Dhaka') @endphp {{ date('Y') }}<a href="#">Sovware</a></p>
            </div>
        </div>
        <div class="col-md-6">
            <div class="footer-menu text-end">
                <ul>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Team</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
        </div>
    </div>
</div> --}}